<?php
//print_r($_REQUEST);
//print_r($_SESSION);
$tran = isset($_REQUEST['t'])?$_REQUEST['t']:'';
$search_param = isset($_SESSION['search_param'])?$_SESSION['search_param']:null;

if($tran == '' || !$search_param) {
    drupal_goto('');die;
}
$cruise_obj = null;
$room_type_number = array_count_values($search_param[$tran]['room_selected']);


if(isset($search_param[$tran]['cruise']) && $search_param[$tran]['cruise'] > 0) {
    $cruise_id = $search_param[$tran]['cruise'];
    $itinerary_id = $search_param[$tran]['arg2'];
    $cruise_obj =  detail_cruise($cruise_id);
    $itinerary = isset($cruise_obj['itinerary'][$itinerary_id])?$cruise_obj['itinerary'][$itinerary_id]:array();

}
//print_r($cruise_obj);
$depart = strtotime($search_param[$tran]['depart']);

$cruise_img = isset($cruise_obj['info']['field_cruise_image']['und'][0]['uri'])?$cruise_obj['info']['field_cruise_image']['und'][0]['uri']:'';
$cruise_img = file_create_url($cruise_img);
$cruise_img = convert_img_url($cruise_img);
$num_day = substr($search_param[$tran]['duration'],0,1);
$num_day = filter_var($num_day,FILTER_SANITIZE_NUMBER_INT);
$return = date('Y-m-d', strtotime($search_param[$tran]['depart'] . ' +'.$num_day.' days'));
$return = strtotime($return);

$num_adult = 0;
$num_child = 0;
$num_infant = 0;

for($r = 0; $r < $search_param[$tran]['no_room']; $r++) {
    $num_adult += $search_param[$tran]['adult'][$r];
    $num_child += $search_param[$tran]['child'][$r];
    $num_infant += $search_param[$tran]['infant'][$r];

}
?>

<?php if($itinerary && $cruise_obj && isset($search_param[$tran]['room_selected']) && count($search_param[$tran]['room_selected']) > 0):?>
<div class="flightPassenger__row">
    <div class="flightPassenger__left">
        <form method="post" action="<?php echo base_path().'review?t='.$tran?>" >

        <div class="formBox">
            <div class="formBox__body">
                <div class="formBox__title">
                    <span class="text20 blueDark medium"><?php echo $cruise_obj['info']['title'] . ' '. $itinerary['title']?></span>
                    <p class="tableIcon__star">
                        <?php echo isset($cruise_obj['info']['field_star']['und'][0]['value'])?html_star($cruise_obj['info']['field_star']['und'][0]['value']):'';?>
                    </p>
                </div>
                <?php for($r = 0; $r < count($search_param[$tran]['room_selected']); $r++):
                    $room_id = $search_param[$tran]['room_selected'][$r];
                    $room_obj = isset($cruise_obj['rooms'][$room_id])?$cruise_obj['rooms'][$room_id]:array();
                    $field_include = isset($room_obj['field_include']['und'])?$room_obj['field_include']['und']:array();
                    ?>
                    <div class="room-item <?php echo ($r == 0)?'first':''?> <?php echo ($r == (count($search_param[$tran]['room_selected']) - 1))?'last':''?>">
                        <p class="text16 medium blueDark"><?php echo $room_obj['title']?></p>
                        <div class="formBox__service">
                            <p class="d-flex"><?php echo get_icon_by_name('field_square');?><?php echo $room_obj['field_square']['und'][0]['value']?></p>
                            <p class="d-flex"><?php echo get_icon_by_name('wifi');?>Free wifi</p>
                            <p class="d-flex"><?php echo get_icon_by_name('window');?>Has window</p>
                            <p class="d-flex"><?php echo get_icon_by_name('bed_type');?><?php echo $room_obj['field_type_of_bed']['und'][0]['value']?></p>
                            <p class="d-flex"><?php echo get_icon_by_name('no_smoking');?>No smoking</p>
                        </div>
                        <a href="#"><p class="blue1">Room Details and Photos</p></a>
                        <div class="formBox__free">
                            <?php for($inc = 0; $inc < count($field_include); $inc++):?>
                                <p class="d-flex"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="9" viewBox="0 0 12 9" fill="none">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M11.8047 0.528636C12.0651 0.788986 12.0651 1.2111 11.8047 1.47145L4.4714 8.80478C4.21106 9.06513 3.78894 9.06513 3.5286 8.80478L0.195262 5.47145C-0.0650874 5.2111 -0.0650874 4.78899 0.195262 4.52864C0.455612 4.26829 0.877722 4.26829 1.13807 4.52864L4 7.39057L10.8619 0.528636C11.1223 0.268287 11.5444 0.268287 11.8047 0.528636Z" fill="#00AA74"/>
                                </svg><?php echo $field_include[$inc]['value']?></p>
                            <?php endfor;?>

                        </div>
                    </div>
                <?php endfor;?>
            </div>
        </div>

        <div class="formBox">
            <div class="formBox__body cancel__refund">
                <p><svg xmlns="http://www.w3.org/2000/svg" width="20" height="16" viewBox="0 0 20 16" fill="none">
                        <path d="M20 4.875V1.75C20 1.41848 19.8683 1.10054 19.6339 0.866116C19.3995 0.631696 19.0815 0.5 18.75 0.5H1.25C0.918479 0.5 0.600537 0.631696 0.366117 0.866116C0.131696 1.10054 0 1.41848 0 1.75L0 4.875H20Z" fill="#5C6AA1"/>
                        <path d="M0 7.375V14.25C0 14.5815 0.131696 14.8995 0.366117 15.1339C0.600537 15.3683 0.918479 15.5 1.25 15.5H18.75C19.0815 15.5 19.3995 15.3683 19.6339 15.1339C19.8683 14.8995 20 14.5815 20 14.25V7.375H0ZM8.125 12.375H2.5V11.125H8.125V12.375ZM17.5 12.375H15V11.125H17.5V12.375Z" fill="#5C6AA1"/>
                    </svg>Cancel before 8:00 AM on Jan 18, 2022 for a full refund</p>
            </div>
        </div>


        <?php
        echo blk_passenger('adult',$tran);
        if($num_child > 0) {
            echo blk_passenger('child',$tran);
        }
        if($num_infant > 0) {
            echo blk_passenger('infant',$tran);
        }
        $area_code = $data['area_code'] ;

        ?>



        <div class="formBox">
            <div class="formBox__body">
                <div class="formBox__item">
                    <div class="formBox__text">
                        <p class="text20 medium blueDark mt5">Contact information</p>
                    </div>
                    <div class="formBox__row">
                        <div class="form-group w-50">
                            <label class="labelStar">Country Code</label>
                            <select class="form-control" name="area_code">
                                <?php if(count($area_code) > 0):?>
                                    <?php foreach ($area_code as $code):?>
                                        <option value="<?php echo $code['description']?> (+<?php echo $code['name']?>)"><?php echo $code['description']?> (+<?php echo $code['name']?>)</option>
                                    <?php endforeach;?>
                                <?php endif;?>

                            </select>
                        </div>
                        <div class="form-group w-50">
                            <label class="labelStar">Phone Number</label>
                            <input type="text" placeholder="Phone Number" name="phone" class="form-control">
                        </div>
                        <div class="form-group w-50">
                            <label class="labelStar">Your Email</label>
                            <input type="text" placeholder="Your Email" name="email" class="form-control">
                        </div>
                        <div class="form-group w-50">
                            <label class="labelStar">Comfirm Email Address</label>
                            <input type="text" placeholder="Comfirm Email Address" class="form-control">
                        </div>
                    </div>
                    <div class="formBox__frequent">
                        <p class="text16 medium blueDark">Special request</p>
                        <div class="frequentBox">
                            <div class="frequentBox__cont">
                                <div class="d-block w-100">
                                    <textarea placeholder="Your Special Request" name="special_request" class="form-control"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="formBox">
            <div class="formBox__body">
                <div class="formBox__item">
                    <div class="formBox__text">
                        <p class="text20 medium blueDark mt5">Extra service</p>
                    </div>
                    <p class="blueDark text16 mb15">Bus transfer service (Hanoi - Halong)</p>
                    <div class="checkbox">
                        <input id="pp135" name="hanoi_halong" class="bus_transfer" type="checkbox" >
                        <label for="pp135">Hanoi to Halong</label>
                    </div>
                    <input type="text" name="hotel_transfer" placeholder="Please provide your Hotel Name and address in Hanoi" class="form-control mt15 mb15">
                    <div class="checkbox">
                        <input id="pp136" type="checkbox" class="bus_transfer" name="halong_hanoi">
                        <label for="pp136">Hanoi to Halong</label>
                    </div>
                    <input type="hidden" name="oneway" value="<?php echo isset($cruise_obj['info']['field_shutter_bus_oneway']['und'][0]['value'])?$cruise_obj['info']['field_shutter_bus_oneway']['und'][0]['value']:0?>" />
                    <input type="hidden" name="roundtrip" value="<?php echo isset($cruise_obj['info']['field_shutter_bus_roundtrip']['und'][0]['value'])?$cruise_obj['info']['field_shutter_bus_roundtrip']['und'][0]['value']:0?>" />

                </div>
            </div>
        </div>
            <input name="tran" type="hidden" value="<?php echo $tran?>" />
        <div class="flightPassenger__btn"><button type="submit" name="review" class="btn btn-orange btn-lg w-100">Next step: Final Confirmation</button></div>
        </form>
    </div>
    <div class="flightPassenger__right">
        <div class="tripSummary">
            <div class="tripSummary__body">
                <div class="tripSummary__text mb15">
                    <span class="text20 blueDark medium">Price summary</span>
                </div>
                <div class="tripSummary__group">
                    <div class="tripSummary__item">
                        <div class="tripSummary__cont">
                            <ul>

                                <?php if(count($room_type_number) > 0):?>
                                    <?php foreach ($room_type_number as $room_id => $num):?>
                                        <li class="medium blueDark"><?php echo $num?> x <?php echo isset($cruise_obj['rooms'][$room_id]['title'])?$cruise_obj['rooms'][$room_id]['title']:'';?></li>
                                    <?php endforeach;?>
                                <?php endif;?>
                                <li class="medium blueDark"><?php echo $itinerary['title']?></li>


                            </ul>
                            <ul><li class="blue1"><a href="#">Change</a></li></ul>
                        </div>
                        <?php
                        $room_label = t('room');

                        if(count($search_param[$tran]['room_selected']) > 1) {
                            $room_label = t('rooms');
                        }

                        $adult_label = t('adult');
                        if($num_adult > 1) {
                            $adult_label = t('adults');
                        }

                        $child_label = t('child');
                        if($num_child > 1) {
                            $child_label = t('children');
                        }

                        $infant_label = t('infant');
                        if($num_infant > 1) {
                            $infant_label = t('infants');
                        }

                        ?>
                        <div class="tripSummary__cont">
                            <ul><li><img src="<?php echo $cruise_img?>"></li></ul>
                            <ul>
                                <li>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 12 12" fill="none">
                                        <path d="M3.33302 3.3335C3.33302 4.798 4.53552 6 5.99952 6C7.46452 6 8.66602 4.798 8.66602 3.3335C8.66602 1.868 7.46502 0.666504 5.99952 0.666504C4.53552 0.666504 3.33302 1.868 3.33302 3.3335ZM11.333 11.3335C11.333 9.3615 8.92902 7.3335 5.99952 7.3335C3.07102 7.3335 0.666016 9.3615 0.666016 11.3335V12H11.333V11.3335Z" fill="#5C6AA1"/>
                                    </svg>
                                    <?php echo count($search_param[$tran]['room_selected'])?> <?php echo $room_label?>,
                                    <?php echo $num_adult .' '.$adult_label;?>
                                    <?php if($num_child > 1):?>
                                     , <?php echo $num_child .' '.$child_label;?>
                                    <?php endif;?>
                                    <?php if($num_infant > 1):?>
                                        , <?php echo $num_infant .' '.$infant_label;?>
                                    <?php endif;?>
                                </li>

                                <li>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M12.0003 13.9997V11.333H6.66699V9.99967H12.0003V7.33301L16.0003 10.6663L12.0003 13.9997Z" fill="#5C6AA1"/>
                                        <path d="M15.3333 2H12V0.666667C12 0.489856 11.9298 0.320286 11.8047 0.195262C11.6797 0.0702379 11.5101 0 11.3333 0C11.1565 0 10.987 0.0702379 10.8619 0.195262C10.7369 0.320286 10.6667 0.489856 10.6667 0.666667V2H5.33333V0.666667C5.33333 0.489856 5.2631 0.320286 5.13807 0.195262C5.01305 0.0702379 4.84348 0 4.66667 0C4.48986 0 4.32029 0.0702379 4.19526 0.195262C4.07024 0.320286 4 0.489856 4 0.666667V2H0.666667C0.489856 2 0.320286 2.07024 0.195262 2.19526C0.0702379 2.32029 0 2.48986 0 2.66667L0 14.6667C0 14.8435 0.0702379 15.013 0.195262 15.1381C0.320286 15.2631 0.489856 15.3333 0.666667 15.3333H10.6667V14H1.33333V4.66667H14.6667V7.33333H16V2.66667C16 2.48986 15.9298 2.32029 15.8047 2.19526C15.6797 2.07024 15.5101 2 15.3333 2Z" fill="#5C6AA1"/>
                                    </svg><?php echo t('Check-in')?>: <?php echo date('D, M d, y',$depart)?>
                                </li>
                                <li>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M3.99967 13.9997V11.333H9.33301V9.99967H3.99967V7.33301L-0.000325203 10.6663L3.99967 13.9997Z" fill="#5C6AA1"/>
                                        <path d="M0.666666 2H4V0.666667C4 0.489856 4.07024 0.320286 4.19526 0.195262C4.32029 0.0702379 4.48986 0 4.66667 0C4.84348 0 5.01305 0.0702379 5.13807 0.195262C5.2631 0.320286 5.33333 0.489856 5.33333 0.666667V2H10.6667V0.666667C10.6667 0.489856 10.7369 0.320286 10.8619 0.195262C10.987 0.0702379 11.1565 0 11.3333 0C11.5101 0 11.6797 0.0702379 11.8047 0.195262C11.9298 0.320286 12 0.489856 12 0.666667V2H15.3333C15.5101 2 15.6797 2.07024 15.8047 2.19526C15.9298 2.32029 16 2.48986 16 2.66667V14.6667C16 14.8435 15.9298 15.013 15.8047 15.1381C15.6797 15.2631 15.5101 15.3333 15.3333 15.3333H5.33333V14H14.6667V4.66667H1.33333V7.33333H0V2.66667C0 2.48986 0.0702372 2.32029 0.195261 2.19526C0.320286 2.07024 0.489855 2 0.666666 2Z" fill="#5C6AA1"/>
                                    </svg><?php echo t('Check-out')?>: <?php echo date('D, M d, y',$return)?>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="tripSummary__item">
                        <div class="tripSummary__ul">
                            <?php $amount = 0; for($i = 0; $i < count($search_param[$tran]['room_selected']); $i++):
                                $room_id = $search_param[$tran]['room_selected'][$i];
                                $room_obj = $cruise_obj['rooms'][$room_id];
                                $total_of_room = calculator_fare($room_obj,$i,$tran);
                                $amount += $total_of_room;
                                ?>
                                    <ul>
                                        <li>
                                            <p class="blueDark">
                                                <?php echo t('Room').' '. ($i + 1);?>
                                            </p>
                                        </li>
                                        <li><p class="blueDark">USD <?php echo number_format($total_of_room);?></p></li>
                                    </ul>
                            <?php endfor;?>
                            <ul>
                                <li>
                                    <p class="blueDark">Number of nights</p>
                                </li>
                                <li><p class="blueDark">x<?php echo $num_day?></p></li>
                            </ul>
                            <ul>
                                <li>
                                    <p class="blueDark">Shutter bus fee</p>
                                </li>
                                <li><p class="blueDark">USD <span id="shutter_bus">0</span></p></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $amount = $amount * $num_day;
                    ?>
                    <input type="hidden" name="total" value="<?php echo $amount?>">
                    <div class="tripSummary__item">
                        <div class="tripSummary__price">
                            <ul>
                                <li>
                                    <p class="blueDark text20 medium">Total charges</p>
                                </li>
                                <li><p class="green400 medium text20">USD <span id="total_charge" total_charge="<?php echo $amount?>"><?php echo number_format($amount)?></span></p>
                                    <p class="blueDark45">Includes taxes & fees</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="flexGroup2 mt15">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M12 0C5.373 0 0 5.373 0 12C0 18.627 5.373 24 12 24C18.627 24 24 18.627 24 12C24 5.373 18.627 0 12 0ZM12 5C14.393 5 16 6.607 16 9H14.75C14.75 7.481 13.519 6.25 12 6.25C10.481 6.25 9.25 7.481 9.25 9H8C8 6.607 9.607 5 12 5ZM17 16.5C17 17.328 16.328 18 15.5 18H8.5C7.672 18 7 17.328 7 16.5V11.5C7 10.672 7.672 10 8.5 10H15.5C16.328 10 17 10.672 17 11.5V16.5Z" fill="#00CA9B"/>
            </svg><span class="blueDark ml15 text12">We are committed to protecting your information</span>
        </div>
    </div>
</div>
<?php endif;?>

<script>
    $('document').ready(function () {
        $('.bus_transfer').click(function () {
            var oneway = $('input[name=oneway]').val();
            var roundtrip = $('input[name=roundtrip]').val();
            var total = 0;

            var total_charge = $('#total_charge').attr('total_charge');

            if($('input[name=hanoi_halong]').is(':checked') && $('input[name=halong_hanoi]').is(':checked')) {
                total = roundtrip;
            } else if($('input[name=hanoi_halong]').is(':checked') && $('input[name=halong_hanoi]').is(':checked') == false) {
                total = oneway;
            } else if($('input[name=hanoi_halong]').is(':checked') == false && $('input[name=halong_hanoi]').is(':checked')) {
                total = oneway;
            }

            $('#shutter_bus').text(total);
            total_charge = parseInt(total_charge) + parseInt(total);
            $('#total_charge').text(total_charge.toString().replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ","));
        });
        $('.general_date').datepicker();
        $('.day').change(function () {
            var day = $(this).find('option:selected').val();
            var month =  $(this).parents('.formBox__date').find('select.month option:selected').val();
            var year =  $(this).parents('.formBox__date').find('select.year option:selected').val();

            if(day == 31) {

                $(this).parents('.formBox__date').find('select.month option[value=2]').addClass('d-none');
                $(this).parents('.formBox__date').find('select.month option[value=4]').addClass('d-none');
                $(this).parents('.formBox__date').find('select.month option[value=6]').addClass('d-none');
                $(this).parents('.formBox__date').find('select.month option[value=9]').addClass('d-none');
                $(this).parents('.formBox__date').find('select.month option[value=11]').addClass('d-none');
            } else if(day == 30) {
                $(this).parents('.formBox__date').find('select.month option').removeClass('d-none');
                $(this).parents('.formBox__date').find('select.month option[value=2]').addClass('d-none');
            } else  if(day == 29) {
                if(month == 2) {
                    var years = $(this).parents('.formBox__date').find('select.year option');
                    if(years.length > 0) {
                        for(var i = 0; i < years.length; i++) {
                            if($(years[i]).val() % 4 != 0) {
                                $(years[i]).addClass('d-none');
                            }
                        }
                        $(this).parents('.formBox__date').find('select.year').change();
                    }
                }



            } else {
                $(this).parents('.formBox__date').find('select.month option').removeClass('d-none');
                $(this).parents('.formBox__date').find('select.year option').removeClass('d-none');
            }
            //$(this).parents('.formBox__date').find('select.month').change();
        });

        $('.month').change(function () {
            var month = $(this).find('option:selected').val();

            var year =  $(this).parents('.formBox__date').find('select.year option:selected').val();

            if(month == 2 || month == 4 || month == 6 || month == 9 || month == 11) {
                $(this).parents('.formBox__date').find('select.day option[value=31]').addClass('d-none');
                if(month == 2) {
                    console.log('1111111');
                    $(this).parents('.formBox__date').find('select.day option[value=30]').addClass('d-none');
                    if(year % 4 != 0) {
                        $(this).parents('.formBox__date').find('select.day option[value=29]').addClass('d-none');
                    }
                    $(this).parents('.formBox__date').find('select.day option[value=""]').prop('selected',true);
                }


            } else  {
                $(this).parents('.formBox__date').find('select.day option').removeClass('d-none');

            }
            $(this).parents('.formBox__date').find('select.day').change();
        });

        $('.year').change(function () {
            var year = $(this).find('option:selected').val();

            var month =  $(this).parents('.formBox__date').find('select.month option:selected').val();
            var day =  $(this).parents('.formBox__date').find('select.day option:selected').val();
            $(this).parents('.formBox__date').find('select.day option').removeClass('d-none');
            if(year % 4 != 0) {
                if(month == 2) {
                    $(this).parents('.formBox__date').find('select.day option[value=29]').addClass('d-none');
                    $(this).parents('.formBox__date').find('select.day option[value=30]').addClass('d-none');
                    $(this).parents('.formBox__date').find('select.day option[value=31]').addClass('d-none');
                }


            } else {
                if(month == 2) {
                    $(this).parents('.formBox__date').find('select.day option[value=29]').removeClass('d-none');
                }

            }
        });

        $('.general_date').datepicker();
        

    });

</script>
