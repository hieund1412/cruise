<?php
global $conf;
$theme = '/sites/all/themes/newtheme/';
$cruise_img = isset($data['info']['field_cruise_image']['und'])?$data['info']['field_cruise_image']['und']:array();
$rooms = $data['rooms'];
$itinerary = null;
$itinerary_id = arg(2);
if(isset($data['itinerary'][$itinerary_id])) {
    $itinerary = $data['itinerary'][$itinerary_id];
}
$list_amenities = list_amenities();
//print_r($list_amenities);die;
//print_r($data);die;
$tran = isset($_REQUEST['t'])?$_REQUEST['t']:0;
$search_param = array();
print_r($_SESSION['search_param']);
if($tran > 0 && isset($_SESSION['search_param'][$tran])) {
    $search_param = $_SESSION['search_param'][$tran];
}


?>
<div class="tabLink">
    <ul>
        <li>
            <a href="#" class="blueDark45">Home</a>
            <svg xmlns="http://www.w3.org/2000/svg" width="8" height="10" viewBox="0 0 8 10" fill="none">
                <path d="M7.12512 4.9999C7.12529 5.13618 7.09639 5.27094 7.04035 5.39517C6.9843 5.5194 6.90241 5.63025 6.80012 5.72031L2.15346 9.80823C1.99948 9.93743 1.80106 10.0013 1.60063 9.98608C1.4002 9.97089 1.21366 9.87789 1.08091 9.72696C0.94816 9.57603 0.879728 9.37915 0.890248 9.17842C0.900768 8.97769 0.989406 8.78904 1.13721 8.65281L5.20054 5.07823C5.21169 5.06845 5.22063 5.05641 5.22675 5.0429C5.23288 5.02939 5.23604 5.01473 5.23604 4.9999C5.23604 4.98506 5.23288 4.9704 5.22675 4.95689C5.22063 4.94338 5.21169 4.93134 5.20054 4.92156L1.13721 1.34698C1.05863 1.28105 0.994033 1.20008 0.947202 1.10882C0.900371 1.01757 0.872254 0.917871 0.864504 0.815594C0.856754 0.713317 0.869528 0.610523 0.902074 0.513254C0.93462 0.415984 0.986282 0.326201 1.05402 0.249184C1.12176 0.172166 1.20422 0.109467 1.29654 0.0647716C1.38886 0.0200767 1.48918 -0.00571349 1.59161 -0.0110817C1.69404 -0.01645 1.79651 -0.00128845 1.89299 0.0335121C1.98948 0.0683116 2.07804 0.122048 2.15346 0.191563L6.79846 4.27823C6.90099 4.36846 6.98315 4.47947 7.03948 4.6039C7.0958 4.72833 7.12499 4.86331 7.12512 4.9999Z" fill="#94A3B8"/>
            </svg>
            <a href="#" class="blueDark45">Day Cruise</a>
            <svg xmlns="http://www.w3.org/2000/svg" width="8" height="10" viewBox="0 0 8 10" fill="none">
                <path d="M7.12512 4.9999C7.12529 5.13618 7.09639 5.27094 7.04035 5.39517C6.9843 5.5194 6.90241 5.63025 6.80012 5.72031L2.15346 9.80823C1.99948 9.93743 1.80106 10.0013 1.60063 9.98608C1.4002 9.97089 1.21366 9.87789 1.08091 9.72696C0.94816 9.57603 0.879728 9.37915 0.890248 9.17842C0.900768 8.97769 0.989406 8.78904 1.13721 8.65281L5.20054 5.07823C5.21169 5.06845 5.22063 5.05641 5.22675 5.0429C5.23288 5.02939 5.23604 5.01473 5.23604 4.9999C5.23604 4.98506 5.23288 4.9704 5.22675 4.95689C5.22063 4.94338 5.21169 4.93134 5.20054 4.92156L1.13721 1.34698C1.05863 1.28105 0.994033 1.20008 0.947202 1.10882C0.900371 1.01757 0.872254 0.917871 0.864504 0.815594C0.856754 0.713317 0.869528 0.610523 0.902074 0.513254C0.93462 0.415984 0.986282 0.326201 1.05402 0.249184C1.12176 0.172166 1.20422 0.109467 1.29654 0.0647716C1.38886 0.0200767 1.48918 -0.00571349 1.59161 -0.0110817C1.69404 -0.01645 1.79651 -0.00128845 1.89299 0.0335121C1.98948 0.0683116 2.07804 0.122048 2.15346 0.191563L6.79846 4.27823C6.90099 4.36846 6.98315 4.47947 7.03948 4.6039C7.0958 4.72833 7.12499 4.86331 7.12512 4.9999Z" fill="#94A3B8"/>
            </svg>
            <a href="#" class="blue1"><?php echo $data['info']['title']?></a>
        </li>
    </ul>
</div>
<div class="cruiseService__title">
    <p class="medium blueDark text20"><?php echo $data['info']['title']?></p>
    <?php echo get_star_html($data['info']['field_star']['und'][0]['value']);?>
</div>
<div class="cruiseService__image__group">
    <div class="row">
        <?php if(count($cruise_img) > 0):
            $first_img = file_create_url($cruise_img[0]['uri']);
            $first_img = convert_img_url($first_img);

            ?>
        <div class="col-4">
            <div class="cruiseService__item">

                <img src="<?php echo $first_img?>" />
            </div>
        </div>
        <div class="col-8">
            <div class="cruiseService__group">
                <?php for($i = 1; $i < count($cruise_img); $i++):
                    $img = file_create_url($cruise_img[$i]['uri']);
                    $img = convert_img_url($img);
                    ?>
                <div class="cruiseService__col">
                    <img src="<?php echo $img?>" />
                </div>
                <?php endfor;?>

            </div>
        </div>
        <?php endif;?>
    </div>
</div>
<div class="cruiseService__inf">
    <div class="cruiseInf__group">
        <div class="cruiseInf__header">
            <p class="medium blueDark">Overview</p>
            <p class="medium blueDark">Room</p>
            <p class="medium blueDark">Itinerary</p>
            <p class="medium blueDark">Amenities</p>
            <p class="medium blueDark">Inclusions & Options</p>
            <p class="medium blueDark">Reviews</p>
            <a href="cruises-details.html" value="" name="home_search" class="btn btn-orange w120">Select room</a>
        </div>
        <div class="cruiseInf__cont">
            <div class="cruiseInf__left">
                <p class="text24 blueDark medium">Overview</p>
                <p class="blueDark">
                   <?php echo isset($data['info']['body']['und'][0]['value'])?$data['info']['body']['und'][0]['value']:''?>
                </p>

            </div>
            <div class="cruiseInf__right">
                <img src="<?php echo $theme?>/images/details8.jpg">
                <p class="blue1">Tuan Chau Island, Ha Long, Vietnam</p>
            </div>
        </div>
    </div>
</div>

<div class="cruiseItinerary__cont">
    <div class="cruiseItinerary__title flexIcon__between cursorPointer titleShow">
        <p class="text24 blueDark medium">Itinerary</p>
        <svg width="14" height="8" viewBox="0 0 14 8" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M0.292893 0.292893C0.683417 -0.0976315 1.31658 -0.0976315 1.70711 0.292893L7 5.58579L12.2929 0.292893C12.6834 -0.097632 13.3166 -0.097632 13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L7.70711 7.70711C7.31658 8.09763 6.68342 8.09763 6.29289 7.70711L0.292893 1.70711C-0.0976314 1.31658 -0.0976314 0.683417 0.292893 0.292893Z" fill="#5C6AA1"/>
        </svg>
    </div>
    <?php if($itinerary):

        ?>
    <div class="cruiseItinerary__main" style="display: none">
        <?php if(count($itinerary['field_content']['und']) > 0):?>

            <?php for($t = 0; $t < count($itinerary['field_content']['und']); $t++):
                $content = trim($itinerary['field_content']['und'][$t]['value']);
                $title = '';
                if(substr($content,0,4) == '<h2>') {
                    $pos = strpos($content, '</h2>');
                    $title = ': '. substr($content,4,$pos);
                    $title = strip_tags($title);
                    $content = substr($content,$pos );
                }

                ?>
                <div class="tripRow">
                    <div class="tripTitle">
                        <svg class="minus" xmlns="http://www.w3.org/2000/svg" width="18" height="24" viewBox="0 0 18 24" fill="none">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M9 2C5.55148 2 2 4.54797 2 9C2 9.98482 2.41279 11.238 3.13802 12.6386C3.852 14.0175 4.81545 15.4391 5.79682 16.7333C6.77554 18.024 7.7567 19.1679 8.49433 19.99C8.67994 20.1969 8.84982 20.383 9 20.5457C9.15018 20.383 9.32006 20.1969 9.50567 19.99C10.2433 19.1679 11.2245 18.024 12.2032 16.7333C13.1845 15.4391 14.148 14.0175 14.862 12.6386C15.5872 11.238 16 9.98482 16 9C16 4.54797 12.4485 2 9 2ZM9 22C8.28852 22.7027 8.28838 22.7026 8.28822 22.7024L8.28104 22.6951L8.26216 22.6759C8.24586 22.6592 8.22221 22.6349 8.19169 22.6034C8.13066 22.5404 8.04215 22.4483 7.93007 22.3299C7.70597 22.0932 7.38735 21.751 7.00567 21.3256C6.2433 20.4759 5.22446 19.2885 4.20318 17.9417C3.18455 16.5984 2.148 15.0762 1.36198 13.5583C0.587213 12.062 0 10.4652 0 9C0 3.25203 4.64852 0 9 0C13.3515 0 18 3.25203 18 9C18 10.4652 17.4128 12.062 16.638 13.5583C15.852 15.0762 14.8155 16.5984 13.7968 17.9417C12.7755 19.2885 11.7567 20.4759 10.9943 21.3256C10.6126 21.751 10.294 22.0932 10.0699 22.3299C9.95785 22.4483 9.86934 22.5404 9.80831 22.6034C9.77779 22.6349 9.75414 22.6592 9.73784 22.6759L9.71896 22.6951L9.71227 22.7019C9.7121 22.7021 9.71148 22.7027 9 22ZM9 22L9.71148 22.7027L9 23.4231L8.28822 22.7024L9 22Z" fill="#5C6AA1"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M5 8H13V10H5V8Z" fill="#5C6AA1"/>
                        </svg>
                        <svg class="d-none plus" xmlns="http://www.w3.org/2000/svg" width="18" height="24" viewBox="0 0 18 24" fill="none">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M9 2C5.55148 2 2 4.54797 2 9C2 9.98482 2.41279 11.238 3.13802 12.6386C3.852 14.0175 4.81545 15.4391 5.79682 16.7333C6.77554 18.024 7.7567 19.1679 8.49433 19.99C8.67994 20.1969 8.84982 20.383 9 20.5457C9.15018 20.383 9.32006 20.1969 9.50567 19.99C10.2433 19.1679 11.2245 18.024 12.2032 16.7333C13.1845 15.4391 14.148 14.0175 14.862 12.6386C15.5872 11.238 16 9.98482 16 9C16 4.54797 12.4485 2 9 2ZM9 22C8.28852 22.7027 8.28838 22.7026 8.28822 22.7024L8.28104 22.6951L8.26216 22.6759C8.24586 22.6592 8.22221 22.6349 8.19169 22.6034C8.13066 22.5404 8.04215 22.4483 7.93007 22.3299C7.70597 22.0932 7.38735 21.751 7.00567 21.3256C6.2433 20.4759 5.22446 19.2885 4.20318 17.9417C3.18455 16.5984 2.148 15.0762 1.36198 13.5583C0.587213 12.062 0 10.4652 0 9C0 3.25203 4.64852 0 9 0C13.3515 0 18 3.25203 18 9C18 10.4652 17.4128 12.062 16.638 13.5583C15.852 15.0762 14.8155 16.5984 13.7968 17.9417C12.7755 19.2885 11.7567 20.4759 10.9943 21.3256C10.6126 21.751 10.294 22.0932 10.0699 22.3299C9.95785 22.4483 9.86934 22.5404 9.80831 22.6034C9.77779 22.6349 9.75414 22.6592 9.73784 22.6759L9.71896 22.6951L9.71227 22.7019C9.7121 22.7021 9.71148 22.7027 9 22ZM9 22L9.71148 22.7027L9 23.4231L8.28822 22.7024L9 22Z" fill="#5C6AA1"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M10 5V13H8V5H10Z" fill="#5C6AA1"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M5 8H13V10H5V8Z" fill="#5C6AA1"></path>
                        </svg>
                        <p class="medium text16 blueDark">Day <?php echo ($t + 1).$title?></p>
                    </div>
                    <div class="cruiseItinerary__trip">
                        <div class="tripContent" style="display: block">
                            <?php echo $content?>
                        </div>

                    </div>
                </div>
            <?php endfor;?>

        <?php endif;?>

    </div>

    <?php endif;?>


</div>

<?php echo blk_form_search();?>

<form method="post" action="<?php echo base_path().'passenger'?>">
<div class="cruiseService__filter">
    <p class="blueDark medium">Filter by</p>
    <button class="active button__filter"><span class="blueDark">All rooms</span></button>
    <button class="button__filter"><span class="blueDark">Free cancellation</span></button>
    <button class="button__filter"><span class="blueDark">Free Breakfast</span></button>
</div>
<?php if(count($search_param) > 0):
    $no_room = $search_param['no_room'];
    $room_types = $search_param['room_type'];
    ?>
    <?php for($r = 0; $r < $no_room; $r++):
        $title = 'Room '. ($r + 1) .': ';
        $child = '';
        $adult = '';
        if($search_param['adult'][$r] > 1) {
            $title .= $search_param['adult'][$r] .' adults';
        } else {
            $title .= $search_param['adult'][$r] .' adult';
        }
        if($search_param['child'][$r] > 0) {
            $title .= ' - ' . $search_param['child'][$r];
            if($search_param['child'][$r] > 1) {
                $title .= ' children';
            } else {
                $title .= ' child';
            }


        }

        if($search_param['infant'][$r] > 0) {
            $title .= ' - ' . $search_param['infant'][$r];
            if($search_param['infant'][$r] > 1) {
                $title .= ' infants';
            } else {
                $title .= ' infant';
            }


        }

    ?>
        <div class="cruiseService__table">
            <div class="cruiseService__table__body">
                <div class="cruiseService__table__main">
                    <div class="cruiseService__table__title">
                        <p class="blueP400 medium text20 mb15"><?php echo $title?></p>
                    </div>
                    <div class="cruiseService__table__header">
                        <div class="cruiseService__table__cell"><p class="medium">Accommodation Type</p></div>
                        <div class="cruiseService__table__cell"><p class="medium">Maximum</p></div>
                        <div class="cruiseService__table__cell"><p class="medium">Price</p></div>
                        <div class="cruiseService__table__cell"><p class="medium">Included</p></div>
                        <div class="cruiseService__table__cell"><p class="medium">Select</p></div>
                    </div>
                    <?php if(count($rooms) > 0):?>
                        <?php foreach ($rooms as $room):
                                $type_room = isset($room['field_type_room']['und'][0]['value'])?$room['field_type_room']['und'][0]['value']:'';
                                $room_img = isset($room['field_cruise_room_image']['und'][0]['uri'])?$room['field_cruise_room_image']['und'][0]['uri']:'';
                                $room_img = file_create_url($room_img);
                                $room_img = convert_img_url($room_img);
                                $max_of_adult = isset($room['field_max_of_adult']['und'][0]['value'])?$room['field_max_of_adult']['und'][0]['value']:0;
                                $all_img_of_room =  array();
                                if(isset($room['field_cruise_room_image']['und']) && count($room['field_cruise_room_image']['und']) > 0) {
                                    for($im = 0; $im < count($room['field_cruise_room_image']['und']); $im++) {
                                        $img = isset($room['field_cruise_room_image']['und'][$im]['uri'])?$room['field_cruise_room_image']['und'][$im]['uri']:'';
                                        $img = file_create_url($img);
                                        $img = convert_img_url($img);
                                        $all_img_of_room[$im] = $img;
                                    }
                                }



                            ?>
                                <?php if($type_room == $room_types[$r]):?>
                                    <div  class="cruiseService__table__row room" room="<?php echo $room['nid']?>" amenities='<?php echo json_encode($room['field_amenities']['und'])?>' room_img='<?php echo json_encode($all_img_of_room)?>'>
                                        <div class="cruiseService__table__cell">
                                            <div class="cruiseService__item__left">
                                                <img src="<?php echo $room_img?>">
                                            </div>
                                            <div class="cruiseService__item__right">
                                                <p class="text20 blueDark medium"><?php echo $room['title']?></p>
                                                <ul>
                                                    <li>
                                                        <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                <path d="M12.64 0.5H3.36C2.60189 0.501322 1.8752 0.803067 1.33913 1.33913C0.803067 1.8752 0.501322 2.60189 0.5 3.36V12.64C0.501322 13.3981 0.803067 14.1248 1.33913 14.6609C1.8752 15.1969 2.60189 15.4987 3.36 15.5H12.64C13.3981 15.4987 14.1248 15.1969 14.6609 14.6609C15.1969 14.1248 15.4987 13.3981 15.5 12.64V3.36C15.4987 2.60189 15.1969 1.8752 14.6609 1.33913C14.1248 0.803067 13.3981 0.501322 12.64 0.5ZM14.5 12.64C14.4987 13.1329 14.3023 13.6052 13.9538 13.9538C13.6052 14.3023 13.1329 14.4987 12.64 14.5H3.36C2.8671 14.4987 2.39477 14.3023 2.04624 13.9538C1.69771 13.6052 1.50132 13.1329 1.5 12.64V3.36C1.50132 2.8671 1.69771 2.39477 2.04624 2.04624C2.39477 1.69771 2.8671 1.50132 3.36 1.5H12.64C13.1329 1.50132 13.6052 1.69771 13.9538 2.04624C14.3023 2.39477 14.4987 2.8671 14.5 3.36V12.64Z" fill="#5C6AA1"/>
                                                                <path d="M12.5 8.92C12.3674 8.92 12.2402 8.97268 12.1464 9.06645C12.0527 9.16021 12 9.28739 12 9.42V11.295L4.705 4H6.58C6.71261 4 6.83979 3.94732 6.93355 3.85355C7.02732 3.75979 7.08 3.63261 7.08 3.5C7.08 3.36739 7.02732 3.24021 6.93355 3.14645C6.83979 3.05268 6.71261 3 6.58 3H3.345C3.2535 3 3.16575 3.03635 3.10105 3.10105C3.03635 3.16575 3 3.2535 3 3.345V6.58C3 6.71261 3.05268 6.83979 3.14645 6.93355C3.24021 7.02732 3.36739 7.08 3.5 7.08C3.63261 7.08 3.75979 7.02732 3.85355 6.93355C3.94732 6.83979 4 6.71261 4 6.58V4.705L11.295 12H9.42C9.28739 12 9.16021 12.0527 9.06645 12.1464C8.97268 12.2402 8.92 12.3674 8.92 12.5C8.92 12.6326 8.97268 12.7598 9.06645 12.8536C9.16021 12.9473 9.28739 13 9.42 13H12.655C12.7465 13 12.8343 12.9637 12.899 12.899C12.9637 12.8343 13 12.7465 13 12.655V9.42C13 9.28739 12.9473 9.16021 12.8536 9.06645C12.7598 8.97268 12.6326 8.92 12.5 8.92Z" fill="#5C6AA1"/>
                                                            </svg><?php echo isset($room['field_square']['und'][0]['value'])?$room['field_square']['und'][0]['value']:''?></p>
                                                    </li>
                                                    <li>
                                                        <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="13" viewBox="0 0 16 13" fill="none">
                                                                <path d="M3.33301 6.36667C4.65072 5.26912 6.31141 4.66809 8.02634 4.66809C9.74127 4.66809 11.402 5.26912 12.7197 6.36667" stroke="#5C6AA1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                                <path d="M0.946289 3.99998C2.89457 2.28263 5.40249 1.33508 7.99962 1.33508C10.5968 1.33508 13.1047 2.28263 15.053 3.99998" stroke="#5C6AA1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                                <path d="M5.68652 8.74002C6.36332 8.25918 7.17297 8.00085 8.00319 8.00085C8.83341 8.00085 9.64306 8.25918 10.3199 8.74002" stroke="#5C6AA1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                                <path d="M8 11.3334H8.00667" stroke="#5C6AA1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                            </svg>Free wifi</p>
                                                        <p><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                                                                <path d="M7 0C3.13973 0 0 3.13973 0 7V14H14V7C14 3.13973 10.8603 0 7 0ZM6.30187 12.6H1.4V7.70187H6.30187V12.6ZM6.30187 6.29813H1.44853C1.76587 3.77067 3.77067 1.76587 6.30187 1.44853V6.29813ZM7.70187 1.44853C10.2293 1.76587 12.2341 3.77067 12.5515 6.30187H7.70187V1.44853ZM12.6 12.6H7.70187V7.70187H12.6V12.6Z" fill="#5C6AA1"/>
                                                            </svg>Air Conditioning</p>
                                                    </li>
                                                    <li>
                                                        <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                <path d="M15 9V12.5C15 12.776 14.776 13 14.5 13C14.224 13 14 12.776 14 12.5V12H2V12.5C2 12.776 1.776 13 1.5 13C1.224 13 1 12.776 1 12.5V9C1 8.173 1.673 7.5 2.5 7.5H13.5C14.327 7.5 15 8.173 15 9Z" fill="#5C6AA1"/>
                                                                <path d="M2.5 6.5V3.5C2.5 3.224 2.724 3 3 3H13C13.276 3 13.5 3.224 13.5 3.5V6.5H12V6C12 5.4485 11.5515 5 11 5H9.5C8.9485 5 8.5 5.4485 8.5 6V6.5H7.5V6C7.5 5.4485 7.0515 5 6.5 5H5C4.4485 5 4 5.4485 4 6V6.5H2.5Z" fill="#5C6AA1"/>
                                                            </svg><?php echo isset($room['field_type_of_bed']['und'][0]['value'])?$room['field_type_of_bed']['und'][0]['value']:''?></p>
                                                        <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                <path d="M11.3333 5.33337C10.9658 5.33337 10.6667 5.03422 10.6667 4.66672C10.6667 3.93137 10.0687 3.33337 9.33334 3.33337H8.33334C8.14909 3.33337 8 3.48247 8 3.66672C8 3.85097 8.14909 4.00006 8.33334 4.00006H9.33334C9.70084 4.00006 10 4.29922 10 4.66672C10 5.40206 10.598 6.00003 11.3333 6.00003C11.7008 6.00003 12 6.29919 12 6.66669V7.66669C12 7.85094 12.1491 8.00003 12.3333 8.00003C12.5176 8.00003 12.6667 7.85094 12.6667 7.66669V6.66669C12.6667 5.93134 12.0687 5.33337 11.3333 5.33337Z" fill="#5C6AA1"/>
                                                                <path d="M11 7.33331H10.3334C10.1495 7.33331 10 7.18391 10 6.99997C10 6.44853 9.55147 5.99997 9.00003 5.99997C8.81613 5.99997 8.66669 5.85056 8.66669 5.66663V4.99997C8.66669 4.81572 8.51759 4.66663 8.33334 4.66663C8.14909 4.66663 8 4.81572 8 4.99997V5.66663C8 6.21806 8.44856 6.66663 9 6.66663C9.18391 6.66663 9.33334 6.81603 9.33334 6.99997C9.33334 7.55141 9.78191 7.99997 10.3333 7.99997H11C11.1843 7.99997 11.3334 7.85088 11.3334 7.66663C11.3334 7.48241 11.1843 7.33331 11 7.33331Z" fill="#5C6AA1"/>
                                                                <path d="M8 0C3.58887 0 0 3.58887 0 8C0 12.4111 3.58887 16 8 16C12.4111 16 16 12.4111 16 8C16 3.58887 12.4111 0 8 0ZM8 14.6667C4.32391 14.6667 1.33334 11.6761 1.33334 8C1.33334 6.40153 1.89975 4.93356 2.84113 3.78381L7.72397 8.66666H3.66666C3.48241 8.66666 3.33331 8.81575 3.33331 9V10.3333C3.33331 10.5176 3.48241 10.6667 3.66666 10.6667H9.72394L12.2162 13.1589C11.0664 14.1002 9.59847 14.6667 8 14.6667ZM13.1589 12.2162L11.6094 10.6667H12.3333C12.5176 10.6667 12.6667 10.5176 12.6667 10.3333V9C12.6667 8.81575 12.5176 8.66666 12.3333 8.66666H9.60938L3.78381 2.84109C4.93356 1.89975 6.40153 1.33334 8 1.33334C11.6761 1.33334 14.6667 4.32391 14.6667 8C14.6667 9.59847 14.1002 11.0664 13.1589 12.2162ZM11.3333 10V9.33334H12V10H11.3333Z" fill="#5C6AA1"/>
                                                            </svg>No smoking</p>
                                                    </li>
                                                </ul>
                                                <button type="button" data-toggle="modal" data-target="#roomDetailPopup" class="viewMore blue1"><span>Room Details and Photos</span></button>
                                            </div>
                                        </div>
                                        <div class="cruiseService__table__cell">
                                            <div class="sleeps__number">
                                                <?php if(count($max_of_adult) > 0):?>
                                                    <div class="sleeps__number__icon">
                                                        <?php for($i = 0; $i < $max_of_adult; $i++):?>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
                                                                <path d="M3.33302 3.3335C3.33302 4.798 4.53552 6 5.99952 6C7.46452 6 8.66602 4.798 8.66602 3.3335C8.66602 1.868 7.46502 0.666504 5.99952 0.666504C4.53552 0.666504 3.33302 1.868 3.33302 3.3335ZM11.333 11.3335C11.333 9.3615 8.92902 7.3335 5.99952 7.3335C3.07102 7.3335 0.666016 9.3615 0.666016 11.3335V12H11.333V11.3335Z" fill="#5C6AA1"/>
                                                            </svg>
                                                        <?php endfor;?>

                                                    </div>
                                                <?php endif;?>
                                            </div>
                                        </div>
                                        <div class="cruiseService__table__cell">
                                            <div class="reserve__room"><p><span class="green400 medium text16">USD <?php echo isset($room['field_price_for_adult']['und'][0]['value'])?$room['field_price_for_adult']['und'][0]['value']:0?>&nbsp;</span><span class="text12 blueDark medium">/night</span></p></div>
                                        </div>
                                        <div class="cruiseService__table__cell">
                                            <?php if(isset($room['field_include']['und']) && count($room['field_include']['und']) > 0):?>
                                                <?php for($i = 0; $i < count($room['field_include']['und']); $i++):?>
                                                    <p class="green500"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="9" viewBox="0 0 12 9" fill="none">
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M11.8047 0.528636C12.0651 0.788986 12.0651 1.2111 11.8047 1.47145L4.4714 8.80478C4.21106 9.06513 3.78894 9.06513 3.5286 8.80478L0.195262 5.47145C-0.0650874 5.2111 -0.0650874 4.78899 0.195262 4.52864C0.455612 4.26829 0.877722 4.26829 1.13807 4.52864L4 7.39057L10.8619 0.528636C11.1223 0.268287 11.5444 0.268287 11.8047 0.528636Z" fill="#00AA74"/>
                                                        </svg><?php echo $room['field_include']['und'][$i]['value']?></p>
                                                <?php endfor;?>
                                            <?php endif;?>
                                        </div>
                                        <div class="cruiseService__table__cell">
                                            <div class="reserve__room"><a class="btn btn-orange w80">Book</a></div>
                                        </div>
                                    </div>
                                <?php endif;?>

                        <?php endforeach;?>
                    <?php endif;?>
                    <input type="hidden" class="room_selected" name="room_selected[<?php echo $r?>]" value="" />
                </div>
            </div>
    </div>

    <?php endfor;?>


<?php else:?>
    <div class="cruiseService__table">
    <div class="cruiseService__table__header">
        <div class="cruiseService__table__cell"><p class="medium">Accommodation Type</p></div>
        <div class="cruiseService__table__cell"><p class="medium">Maximum</p></div>
        <div class="cruiseService__table__cell"><p class="medium">Price</p></div>
        <div class="cruiseService__table__cell"><p class="medium">Included</p></div>
        <div class="cruiseService__table__cell"><p class="medium">Select</p></div>
    </div>
    <?php if(count($rooms) > 0):?>
    <?php foreach ($rooms as $room):


    $room_img = isset($room['field_cruise_room_image']['und'][0]['uri'])?$room['field_cruise_room_image']['und'][0]['uri']:'';
    $room_img = file_create_url($room_img);
    $room_img = convert_img_url($room_img);
    $max_of_adult = isset($room['field_max_of_adult']['und'][0]['value'])?$room['field_max_of_adult']['und'][0]['value']:0;
    $all_img_of_room =  array();
    if(isset($room['field_cruise_room_image']['und']) && count($room['field_cruise_room_image']['und']) > 0) {
        for($im = 0; $im < count($room['field_cruise_room_image']['und']); $im++) {
            $img = isset($room['field_cruise_room_image']['und'][$im]['uri'])?$room['field_cruise_room_image']['und'][$im]['uri']:'';
            $img = file_create_url($img);
            $img = convert_img_url($img);
            $all_img_of_room[$im] = $img;
        }
    }


    ?>
    <div  class="cruiseService__table__row room" amenities='<?php echo json_encode($room['field_amenities']['und'])?>' room_img='<?php echo json_encode($all_img_of_room)?>'>
        <div class="cruiseService__table__cell">
            <div class="cruiseService__item__left">
                <img src="<?php echo $room_img?>">
            </div>
            <div class="cruiseService__item__right">
                <p class="text20 blueDark medium"><?php echo $room['title']?></p>
                <ul>
                    <li>
                        <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                <path d="M12.64 0.5H3.36C2.60189 0.501322 1.8752 0.803067 1.33913 1.33913C0.803067 1.8752 0.501322 2.60189 0.5 3.36V12.64C0.501322 13.3981 0.803067 14.1248 1.33913 14.6609C1.8752 15.1969 2.60189 15.4987 3.36 15.5H12.64C13.3981 15.4987 14.1248 15.1969 14.6609 14.6609C15.1969 14.1248 15.4987 13.3981 15.5 12.64V3.36C15.4987 2.60189 15.1969 1.8752 14.6609 1.33913C14.1248 0.803067 13.3981 0.501322 12.64 0.5ZM14.5 12.64C14.4987 13.1329 14.3023 13.6052 13.9538 13.9538C13.6052 14.3023 13.1329 14.4987 12.64 14.5H3.36C2.8671 14.4987 2.39477 14.3023 2.04624 13.9538C1.69771 13.6052 1.50132 13.1329 1.5 12.64V3.36C1.50132 2.8671 1.69771 2.39477 2.04624 2.04624C2.39477 1.69771 2.8671 1.50132 3.36 1.5H12.64C13.1329 1.50132 13.6052 1.69771 13.9538 2.04624C14.3023 2.39477 14.4987 2.8671 14.5 3.36V12.64Z" fill="#5C6AA1"/>
                                <path d="M12.5 8.92C12.3674 8.92 12.2402 8.97268 12.1464 9.06645C12.0527 9.16021 12 9.28739 12 9.42V11.295L4.705 4H6.58C6.71261 4 6.83979 3.94732 6.93355 3.85355C7.02732 3.75979 7.08 3.63261 7.08 3.5C7.08 3.36739 7.02732 3.24021 6.93355 3.14645C6.83979 3.05268 6.71261 3 6.58 3H3.345C3.2535 3 3.16575 3.03635 3.10105 3.10105C3.03635 3.16575 3 3.2535 3 3.345V6.58C3 6.71261 3.05268 6.83979 3.14645 6.93355C3.24021 7.02732 3.36739 7.08 3.5 7.08C3.63261 7.08 3.75979 7.02732 3.85355 6.93355C3.94732 6.83979 4 6.71261 4 6.58V4.705L11.295 12H9.42C9.28739 12 9.16021 12.0527 9.06645 12.1464C8.97268 12.2402 8.92 12.3674 8.92 12.5C8.92 12.6326 8.97268 12.7598 9.06645 12.8536C9.16021 12.9473 9.28739 13 9.42 13H12.655C12.7465 13 12.8343 12.9637 12.899 12.899C12.9637 12.8343 13 12.7465 13 12.655V9.42C13 9.28739 12.9473 9.16021 12.8536 9.06645C12.7598 8.97268 12.6326 8.92 12.5 8.92Z" fill="#5C6AA1"/>
                            </svg><?php echo isset($room['field_square']['und'][0]['value'])?$room['field_square']['und'][0]['value']:''?></p>
                    </li>
                    <li>
                        <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="13" viewBox="0 0 16 13" fill="none">
                                <path d="M3.33301 6.36667C4.65072 5.26912 6.31141 4.66809 8.02634 4.66809C9.74127 4.66809 11.402 5.26912 12.7197 6.36667" stroke="#5C6AA1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M0.946289 3.99998C2.89457 2.28263 5.40249 1.33508 7.99962 1.33508C10.5968 1.33508 13.1047 2.28263 15.053 3.99998" stroke="#5C6AA1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M5.68652 8.74002C6.36332 8.25918 7.17297 8.00085 8.00319 8.00085C8.83341 8.00085 9.64306 8.25918 10.3199 8.74002" stroke="#5C6AA1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M8 11.3334H8.00667" stroke="#5C6AA1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>Free wifi</p>
                        <p><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                                <path d="M7 0C3.13973 0 0 3.13973 0 7V14H14V7C14 3.13973 10.8603 0 7 0ZM6.30187 12.6H1.4V7.70187H6.30187V12.6ZM6.30187 6.29813H1.44853C1.76587 3.77067 3.77067 1.76587 6.30187 1.44853V6.29813ZM7.70187 1.44853C10.2293 1.76587 12.2341 3.77067 12.5515 6.30187H7.70187V1.44853ZM12.6 12.6H7.70187V7.70187H12.6V12.6Z" fill="#5C6AA1"/>
                            </svg>Air Conditioning</p>
                    </li>
                    <li>
                        <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                <path d="M15 9V12.5C15 12.776 14.776 13 14.5 13C14.224 13 14 12.776 14 12.5V12H2V12.5C2 12.776 1.776 13 1.5 13C1.224 13 1 12.776 1 12.5V9C1 8.173 1.673 7.5 2.5 7.5H13.5C14.327 7.5 15 8.173 15 9Z" fill="#5C6AA1"/>
                                <path d="M2.5 6.5V3.5C2.5 3.224 2.724 3 3 3H13C13.276 3 13.5 3.224 13.5 3.5V6.5H12V6C12 5.4485 11.5515 5 11 5H9.5C8.9485 5 8.5 5.4485 8.5 6V6.5H7.5V6C7.5 5.4485 7.0515 5 6.5 5H5C4.4485 5 4 5.4485 4 6V6.5H2.5Z" fill="#5C6AA1"/>
                            </svg><?php echo isset($room['field_type_of_bed']['und'][0]['value'])?$room['field_type_of_bed']['und'][0]['value']:''?></p>
                        <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                <path d="M11.3333 5.33337C10.9658 5.33337 10.6667 5.03422 10.6667 4.66672C10.6667 3.93137 10.0687 3.33337 9.33334 3.33337H8.33334C8.14909 3.33337 8 3.48247 8 3.66672C8 3.85097 8.14909 4.00006 8.33334 4.00006H9.33334C9.70084 4.00006 10 4.29922 10 4.66672C10 5.40206 10.598 6.00003 11.3333 6.00003C11.7008 6.00003 12 6.29919 12 6.66669V7.66669C12 7.85094 12.1491 8.00003 12.3333 8.00003C12.5176 8.00003 12.6667 7.85094 12.6667 7.66669V6.66669C12.6667 5.93134 12.0687 5.33337 11.3333 5.33337Z" fill="#5C6AA1"/>
                                <path d="M11 7.33331H10.3334C10.1495 7.33331 10 7.18391 10 6.99997C10 6.44853 9.55147 5.99997 9.00003 5.99997C8.81613 5.99997 8.66669 5.85056 8.66669 5.66663V4.99997C8.66669 4.81572 8.51759 4.66663 8.33334 4.66663C8.14909 4.66663 8 4.81572 8 4.99997V5.66663C8 6.21806 8.44856 6.66663 9 6.66663C9.18391 6.66663 9.33334 6.81603 9.33334 6.99997C9.33334 7.55141 9.78191 7.99997 10.3333 7.99997H11C11.1843 7.99997 11.3334 7.85088 11.3334 7.66663C11.3334 7.48241 11.1843 7.33331 11 7.33331Z" fill="#5C6AA1"/>
                                <path d="M8 0C3.58887 0 0 3.58887 0 8C0 12.4111 3.58887 16 8 16C12.4111 16 16 12.4111 16 8C16 3.58887 12.4111 0 8 0ZM8 14.6667C4.32391 14.6667 1.33334 11.6761 1.33334 8C1.33334 6.40153 1.89975 4.93356 2.84113 3.78381L7.72397 8.66666H3.66666C3.48241 8.66666 3.33331 8.81575 3.33331 9V10.3333C3.33331 10.5176 3.48241 10.6667 3.66666 10.6667H9.72394L12.2162 13.1589C11.0664 14.1002 9.59847 14.6667 8 14.6667ZM13.1589 12.2162L11.6094 10.6667H12.3333C12.5176 10.6667 12.6667 10.5176 12.6667 10.3333V9C12.6667 8.81575 12.5176 8.66666 12.3333 8.66666H9.60938L3.78381 2.84109C4.93356 1.89975 6.40153 1.33334 8 1.33334C11.6761 1.33334 14.6667 4.32391 14.6667 8C14.6667 9.59847 14.1002 11.0664 13.1589 12.2162ZM11.3333 10V9.33334H12V10H11.3333Z" fill="#5C6AA1"/>
                            </svg>No smoking</p>
                    </li>
                </ul>
                <button type="button" data-toggle="modal" data-target="#roomDetailPopup" class="viewMore blue1"><span>Room Details and Photos</span></button>
            </div>
        </div>
        <div class="cruiseService__table__cell">
            <div class="sleeps__number">
                <?php if(count($max_of_adult) > 0):?>
                    <div class="sleeps__number__icon">
                        <?php for($i = 0; $i < $max_of_adult; $i++):?>
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
                                <path d="M3.33302 3.3335C3.33302 4.798 4.53552 6 5.99952 6C7.46452 6 8.66602 4.798 8.66602 3.3335C8.66602 1.868 7.46502 0.666504 5.99952 0.666504C4.53552 0.666504 3.33302 1.868 3.33302 3.3335ZM11.333 11.3335C11.333 9.3615 8.92902 7.3335 5.99952 7.3335C3.07102 7.3335 0.666016 9.3615 0.666016 11.3335V12H11.333V11.3335Z" fill="#5C6AA1"/>
                            </svg>
                        <?php endfor;?>

                    </div>
                <?php endif;?>
            </div>
        </div>
        <div class="cruiseService__table__cell">
            <div class="reserve__room"><p><span class="green400 medium text16">USD <?php echo isset($room['field_price_for_adult']['und'][0]['value'])?$room['field_price_for_adult']['und'][0]['value']:0?>&nbsp;</span><span class="text12 blueDark medium">/night</span></p></div>
        </div>
        <div class="cruiseService__table__cell">
            <?php if(isset($room['field_include']['und']) && count($room['field_include']['und']) > 0):?>
                <?php for($i = 0; $i < count($room['field_include']['und']); $i++):?>
                    <p class="green500"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="9" viewBox="0 0 12 9" fill="none">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M11.8047 0.528636C12.0651 0.788986 12.0651 1.2111 11.8047 1.47145L4.4714 8.80478C4.21106 9.06513 3.78894 9.06513 3.5286 8.80478L0.195262 5.47145C-0.0650874 5.2111 -0.0650874 4.78899 0.195262 4.52864C0.455612 4.26829 0.877722 4.26829 1.13807 4.52864L4 7.39057L10.8619 0.528636C11.1223 0.268287 11.5444 0.268287 11.8047 0.528636Z" fill="#00AA74"/>
                        </svg><?php echo $room['field_include']['und'][$i]['value']?></p>
                <?php endfor;?>
            <?php endif;?>
        </div>
        <div class="cruiseService__table__cell">
            <div class="reserve__room"><a  class="btn btn-orange w80">Book</a></div>
        </div>
    </div>
    <?php endforeach;?>
    <?php endif;?>
</div>
<?php endif;?>

<div class="flightPassenger__btn"><input type="submit" name="passenger" class="btn btn-orange btn-lg w-100" value="Next step: Passenger"></div>
    <input type="hidden" name="tran" value="<?php echo $tran?>" />
</form>
<div class="cruiseAmenities">
    <div class="flexIcon__between cursorPointer titleShow">
        <p class="medium text24 blueDark">Amenities</p>
        <svg width="14" height="8" viewBox="0 0 14 8" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M0.292893 0.292893C0.683417 -0.0976315 1.31658 -0.0976315 1.70711 0.292893L7 5.58579L12.2929 0.292893C12.6834 -0.097632 13.3166 -0.097632 13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L7.70711 7.70711C7.31658 8.09763 6.68342 8.09763 6.29289 7.70711L0.292893 1.70711C-0.0976314 1.31658 -0.0976314 0.683417 0.292893 0.292893Z" fill="#5C6AA1"/>
        </svg>
    </div>
    <div class="cruiseAmenities__group" style="display: none">
        <ul>
            <li>
                <p class="blueDark medium text20">Things to do, ways to relax</p>
            </li>
            <?php if(isset($data['info']['field_thing_to_do_relax']['und']) && count($data['info']['field_thing_to_do_relax']['und']) > 0):?>
                <?php for($i = 0; $i < count($data['info']['field_thing_to_do_relax']['und']); $i++):
                    $tid = $data['info']['field_thing_to_do_relax']['und'][$i]['tid'];
                    $item = isset($list_amenities[$tid])?$list_amenities[$tid]:'';
                    ?>
                    <?php if($item != ''):?>
                    <li>
                        <p class="blueDark"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="9" viewBox="0 0 12 9" fill="none">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M11.8047 0.528636C12.0651 0.788986 12.0651 1.2111 11.8047 1.47145L4.4714 8.80478C4.21106 9.06513 3.78894 9.06513 3.5286 8.80478L0.195262 5.47145C-0.0650874 5.2111 -0.0650874 4.78899 0.195262 4.52864C0.455612 4.26829 0.877722 4.26829 1.13807 4.52864L4 7.39057L10.8619 0.528636C11.1223 0.268287 11.5444 0.268287 11.8047 0.528636Z" fill="#5C6AA1"></path>
                            </svg><?php echo $item?></p>
                    </li>
                    <?php endif;?>
                <?php endfor;?>
            <?php endif;?>

        </ul>
        <ul>
            <li>
                <p class="blueDark medium text20">Dining, drinking, and snacking</p>
            </li>
            <?php if(isset($data['info']['field_drink_and_snacking']['und']) && count($data['info']['field_drink_and_snacking']['und']) > 0):?>
                <?php for($i = 0; $i < count($data['info']['field_drink_and_snacking']['und']); $i++):
                    $tid = $data['info']['field_drink_and_snacking']['und'][$i]['tid'];
                    $item = isset($list_amenities[$tid])?$list_amenities[$tid]:'';
                    ?>
                    <?php if($item != ''):?>
                    <li>
                        <p class="blueDark"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="9" viewBox="0 0 12 9" fill="none">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M11.8047 0.528636C12.0651 0.788986 12.0651 1.2111 11.8047 1.47145L4.4714 8.80478C4.21106 9.06513 3.78894 9.06513 3.5286 8.80478L0.195262 5.47145C-0.0650874 5.2111 -0.0650874 4.78899 0.195262 4.52864C0.455612 4.26829 0.877722 4.26829 1.13807 4.52864L4 7.39057L10.8619 0.528636C11.1223 0.268287 11.5444 0.268287 11.8047 0.528636Z" fill="#5C6AA1"></path>
                            </svg><?php echo $item?></p>
                    </li>
                <?php endif;?>
                <?php endfor;?>
            <?php endif;?>
        </ul>
        <ul>
            <li>
                <p class="blueDark medium text20">Services and conveniences</p>
            </li>
            <?php if(isset($data['info']['field_service_and_convenience']['und']) && count($data['info']['field_service_and_convenience']['und']) > 0):?>
                <?php for($i = 0; $i < count($data['info']['field_service_and_convenience']['und']); $i++):
                    $tid = $data['info']['field_service_and_convenience']['und'][$i]['tid'];
                    $item = isset($list_amenities[$tid])?$list_amenities[$tid]:'';
                    ?>
                    <?php if($item != ''):?>
                    <li>
                        <p class="blueDark"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="9" viewBox="0 0 12 9" fill="none">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M11.8047 0.528636C12.0651 0.788986 12.0651 1.2111 11.8047 1.47145L4.4714 8.80478C4.21106 9.06513 3.78894 9.06513 3.5286 8.80478L0.195262 5.47145C-0.0650874 5.2111 -0.0650874 4.78899 0.195262 4.52864C0.455612 4.26829 0.877722 4.26829 1.13807 4.52864L4 7.39057L10.8619 0.528636C11.1223 0.268287 11.5444 0.268287 11.8047 0.528636Z" fill="#5C6AA1"></path>
                            </svg><?php echo $item?></p>
                    </li>
                <?php endif;?>
                <?php endfor;?>
            <?php endif;?>
        </ul>
    </div>
</div>
<div class="inclusions__options">
    <div class="flexIcon__between cursorPointer titleShow">
        <p class="medium text24 blueDark">Inclusions & Options</p>
        <svg width="14" height="8" viewBox="0 0 14 8" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M0.292893 0.292893C0.683417 -0.0976315 1.31658 -0.0976315 1.70711 0.292893L7 5.58579L12.2929 0.292893C12.6834 -0.097632 13.3166 -0.097632 13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L7.70711 7.70711C7.31658 8.09763 6.68342 8.09763 6.29289 7.70711L0.292893 1.70711C-0.0976314 1.31658 -0.0976314 0.683417 0.292893 0.292893Z" fill="#5C6AA1"/>
        </svg>
    </div>

    <div class="inclusions__options__main" style="display: none">
    <?php if(isset($data['info']['field_inclusions_options']['und'])):?>
        <?php foreach ($data['info']['field_inclusions_options']['und'] as $inclusions):?>
            <div class="inclusions__options__cont">
        <div class="inclusions__left">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M17 12H7" stroke="#5C6AA1" stroke-width="2" stroke-miterlimit="10" stroke-linecap="square"/>
                <path d="M12 23C18.0751 23 23 18.0751 23 12C23 5.92487 18.0751 1 12 1C5.92487 1 1 5.92487 1 12C1 18.0751 5.92487 23 12 23Z" stroke="#5C6AA1" stroke-width="2" stroke-miterlimit="10" stroke-linecap="square"/>
            </svg>
        </div>
        <div class="inclusions__right blueDark">
            <?php echo $inclusions['value'];?>
        </div>
    </div>
        <?php endforeach;?>
    <?php endif;?>
    </div>

</div>
<?php
$star = isset($data['info']['field_star']['und'][0]['value'])?$data['info']['field_star']['und'][0]['value']:'';
$field_excellent = isset($data['info']['field_excellent']['und'][0]['value'])?$data['info']['field_excellent']['und'][0]['value']:'';
$field_good = isset($data['info']['field_good']['und'][0]['value'])?$data['info']['field_good']['und'][0]['value']:'';
$field_okay = isset($data['info']['field_okay']['und'][0]['value'])?$data['info']['field_okay']['und'][0]['value']:'';
$field_poor = isset($data['info']['field_poor']['und'][0]['value'])?$data['info']['field_poor']['und'][0]['value']:'';
$field_terrible = isset($data['info']['field_poor']['und'][0]['value'])?$data['info']['field_poor']['und'][0]['value']:'';

$field_cleanliness = isset($data['info']['field_cleanliness']['und'][0]['value'])?$data['info']['field_cleanliness']['und'][0]['value']:'';
$field_review_amenities = isset($data['info']['field_review_amenities']['und'][0]['value'])?$data['info']['field_review_amenities']['und'][0]['value']:'';
$field_staff_and_service = isset($data['info']['field_staff_and_service']['und'][0]['value'])?$data['info']['field_staff_and_service']['und'][0]['value']:'';
$field_property_condition_facilit = isset($data['info']['field_property_condition_facilit']['und'][0]['value'])?$data['info']['field_property_condition_facilit']['und'][0]['value']:'';
?>
<div class="customer__rating__score">
    <div class="rating__top">
        <div class="rating__cont">
            <span class="medium blueDark"><?php echo $star?></span>
            <div class="rating__all__reviews">
                <p class="text24 medium blueDark">Wonderful</p>
                <a href="#"><p class="blue1">Verified review</p></a>
            </div>
        </div>
        <div class="rating__line">
            <div class="rating__line__item">
                <div class="ratingItem__top blueDark">
                    <p>5 - Excellent</p>
                    <p><?php echo $field_excellent?></p>
                </div>
                <div class="ratingItem__Bottom">
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-5"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rating__line__item">
                <div class="ratingItem__top blueDark">
                    <p>4 - Good</p>
                    <p><?php echo $field_good?></p>
                </div>
                <div class="ratingItem__Bottom">
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-4"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rating__line__item">
                <div class="ratingItem__top blueDark">
                    <p>3 - Okay</p>
                    <p><?php echo $field_okay?></p>
                </div>
                <div class="ratingItem__Bottom">
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-3"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rating__line__item">
                <div class="ratingItem__top blueDark">
                    <p>2 - Poor</p>
                    <p><?php echo $field_poor?></p>
                </div>
                <div class="ratingItem__Bottom">
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-2"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rating__line__item">
                <div class="ratingItem__top blueDark">
                    <p>1 - Terrible</p>
                    <p><?php echo $field_terrible?></p>
                </div>
                <div class="ratingItem__Bottom">
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-1"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="rating__number">
            <ul>
                <li>
                    <p class="text24 medium blueDark"><?php echo $field_cleanliness?></p>
                    <p class="blueDark">Cleanliness</p>
                </li>
                <li>
                    <p class="text24 medium blueDark"><?php echo $field_staff_and_service?></p>
                    <p class="blueDark">Staff &amp; service</p>
                </li>
            </ul>
            <ul>
                <li>
                    <p class="text24 medium blueDark"><?php echo $field_review_amenities?></p>
                    <p class="blueDark">Amenities</p>
                </li>
                <li>
                    <p class="text24 medium blueDark"><?php echo $field_property_condition_facilit?></p>
                    <p class="blueDark">Property condition &amp; facilities</p>
                </li>
            </ul>
        </div>
    </div>
    <div class="rating__bottom">
        <?php if(isset($data['review']) && count($data['review']) > 0):?>
            <?php $i = 0; foreach ($data['review'] as $ob):

                if(isset($ob['avatar'])) {
                    $avatar = $ob['avatar'];
                } else {
                    $avatar = $theme.'images/avatar.jpg';
                }
                $country = isset($ob['field_country']['und'][0]['value'])?$ob['field_country']['und'][0]['value']:'United States';
                ?>
                <div class="rating__bottom__group <?php echo ($i > 4)?'d-none':''?>" >
                    <div class="ratingBottom__point">
                        <p class="colorWhite text24 medium"><?php echo $ob['field_point']['und'][0]['value']?></p>
                        <p class="text24 medium blueDark"><?php echo $ob['title']?></p>
                    </div>
                    <div class="ratingBottom__user">
                        <img width="50px" height="50px" src="<?php echo $avatar?>">
                        <p>
                            <span class="text16 medium blueDark"><?php echo $ob['field_author']['und'][0]['value']?></span>
                            <span class="blueDark"><?php echo $ob['field_date']['und'][0]['value']?></span>
                        </p>
                    </div>
                    <div class="ratingBottom__cont">
                        <p class="text16 blueDark"><?php echo $ob['body']['und'][0]['value']?></p>
                    </div>
                </div>
            <?php $i++; endforeach;?>
        <?php endif;?>

    </div>
</div>

<?php

echo blk_room_detail_popup($data);
?>
<input type="hidden" id="all_amenities" value="<?php echo htmlentities(json_encode($list_amenities))?>" />

<script>
$('document').ready(function () {
    $('.tripTitle').click(function () {
        $(this).parents('.tripRow').find('div.tripContent').toggle();
        if($(this).find('svg.minus').hasClass('d-none')) {
            $(this).find('svg.minus').removeClass('d-none');
        } else {
            $(this).find('svg.minus').addClass('d-none');
        }
        if($(this).find('svg.plus').hasClass('d-none')) {
            $(this).find('svg.plus').removeClass('d-none');
        } else {
            $(this).find('svg.plus').addClass('d-none');
        }
    });
    $('.reserve__room a').click(function () {
        if($(this).hasClass('change')) {
            $(this).text('Book').removeClass('change');
            $(this).parents('.cruiseService__table').find('div.cruiseService__table__row').removeClass('d-none');
            $(this).parents('.cruiseService__table').find('input.room_selected').val('');
        } else {
            var room_id = $(this).parents('.cruiseService__table__row').attr('room');
            console.log(room_id);
            $(this).text('Change').addClass('change');
            $(this).parents('.cruiseService__table').find('div.cruiseService__table__row').addClass('d-none');
            $(this).parents('.cruiseService__table__row').removeClass('d-none');
            $(this).parents('.cruiseService__table').find('input.room_selected').val(room_id);

        }


    });
    $('#roomDetailPopup').on('show.bs.modal', function (e) {
        var room_img_str =$(e.relatedTarget).parents('.room').attr('room_img');
        var total_overview = parseInt($('#total_overview').text());
        var total = 0;
        var all_img = $('#roomDetailPopup .roomType__image').html();
        if(room_img_str != '') {
            var room_img = JSON.parse(room_img_str);
            if(room_img && room_img.length > 0) {
                total += room_img.length + total_overview;
                $('#total_img').text(total);
                $('#total_img_room').text(room_img.length);
                for(var i = 0; i < room_img.length; i++) {
                    all_img += '<img src="' + room_img[i] + '" />';
                }

               $('#roomDetailPopup .roomType__image').html(all_img);

            }
        }

        //show amenities__item
        var amenities__item = $(e.relatedTarget).parents('.room').attr('amenities');
        amenities__item = JSON.parse(amenities__item);
        var amenities_html = '';

        var all_amenities = $('#all_amenities').val();
        all_amenities = JSON.parse(all_amenities);
        if(amenities__item.length > 0) {
            for(var i = 0; i < amenities__item.length; i++) {
                var tid = amenities__item[i]['tid'];
                if(all_amenities[tid]) {
                    amenities_html += '<li class="blueDark"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="13" viewBox="0 0 16 13" fill="none">\n' +
                        '                                            <path d="M3.33301 6.36667C4.65072 5.26912 6.31141 4.66809 8.02634 4.66809C9.74127 4.66809 11.402 5.26912 12.7197 6.36667" stroke="#5C6AA1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\n' +
                        '                                            <path d="M0.946289 3.99998C2.89457 2.28263 5.40249 1.33508 7.99962 1.33508C10.5968 1.33508 13.1047 2.28263 15.053 3.99998" stroke="#5C6AA1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\n' +
                        '                                            <path d="M5.68652 8.74002C6.36332 8.25918 7.17297 8.00085 8.00319 8.00085C8.83341 8.00085 9.64306 8.25918 10.3199 8.74002" stroke="#5C6AA1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\n' +
                        '                                            <path d="M8 11.3334H8.00667" stroke="#5C6AA1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\n' +
                        '                                        </svg>' +all_amenities[tid]+ '</li>';
                }
            }
        }
        $('#roomDetailPopup .amenities__item ul').html(amenities_html);

        $('#roomDetailPopup .roomType__image img').click(function () {
            var src = $(this).attr('src');
            $('#roomDetailPopup .roomPopup__image img').attr('src',src);
        });
    });


});
</script>
<script>
    $('.titleShow').click(function () {
        $(this).next().slideToggle(300);
        $(this).toggleClass('rotate');
    });


    $('.homeLeft__button').click(function () {
        var acb = $('.homeOffers__group').width();
        $(this).parents('.homeLeft').toggleClass('MvE2');
        if($('.homeLeft').hasClass('MvE2')){
            $('.homeRight').addClass('MvE1');
            $('.footer').addClass('MvE1');

        }else {
            $('.homeRight').removeClass('MvE1');
            $('.footer').removeClass('MvE1');
        }
    });

    $('.t-datepicker').tDatePicker({
        autoClose: true,
        titleCheckIn: 'Check in',
        titleCheckOut: 'Return',
        titleDateRange: 'day',
        titleDateRanges: 'days',
        iconDate: '',
        iconArrowTop: false
    });
</script>
<script>
    // header
    $(".header__toggle").click(function () {
        $('.navbarBox').addClass('open');
    });
    $(".navbarBox__close, .navbarBox__backdrop").click(function () {
        $('.navbarBox').removeClass('open');
    });
    if (screen.width < 768) {
        $('.navbarBox__list ul').slideUp(300);
        $(".navbarBox__title").click(function () {
            $(this).toggleClass('active');
            $(this).next('.navbarBox__list ul').slideToggle(300);
        });
    };
</script>
<script>
    $(".inputPlace").click(function () {
        $(this).next('.suggestion').addClass('open');
    });
    $(document).mouseup(function (e) {
        var suggestion = $('.suggestion');
        if (!suggestion.is(e.target) && suggestion.has(e.target).length === 0) {
            $('.suggestion').removeClass('open');
        }
        ;
    });
</script>