
<div class="homeDestinations">
    <div class="container1">
        <div class="title1"><span>Popular destinations</span></div>
        <div class="homeDestinations__group">
            <div class="homeDestinations__row">
                <?php if(isset($data['destination']) && count($data['destination']) > 0):?>
                    <?php foreach ($data['destination'] as $ob):?>
                        <div class="homeDestinations__item">
                            <div class="destinations">
                                <div class="destinations__img">
                                    <img src="<?php echo isset($ob['thumbnail'])?$ob['thumbnail']:''?>">
                                </div>
                                <div class="destinations__cont">
                                    <div class="offers__top">
                                        <p class="text16 medium blueDark"><?php echo $ob['title']?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach;?>
                <?php endif;?>
            </div>
        </div>
    </div>
</div>