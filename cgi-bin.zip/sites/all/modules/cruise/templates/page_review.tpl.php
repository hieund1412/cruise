<div class="text24 blueDark medium mb15"><span>Review your booking</span></div>
<div class="flightReview__main">
    <div class="orderCode">
        <div class="orderCode__label">Order code: G-46f76a</div>
        <p class="blueDark">The order number is for your reference only, NOT for check-in and boarding!</p>
    </div>
    <div class="formBox">
        <div class="formBox__body">
            <div class="formBox__review__item">
                <div class="formBox__image">
                    <img src="images/in1.jpg">
                </div>
                <div class="formBox__cont">
                    <div class="formBox__title">
                        <span class="text20 blueDark medium">Paradise Elegance Cruise 2 Days</span>
                        <p class="tableIcon__star">
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="11" viewBox="0 0 12 11" fill="none">
                                <path d="M6 0L7.34708 4.1459H11.7063L8.17963 6.7082L9.52671 10.8541L6 8.2918L2.47329 10.8541L3.82037 6.7082L0.293661 4.1459H4.65292L6 0Z" fill="#FD6431"></path>
                            </svg>
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="11" viewBox="0 0 12 11" fill="none">
                                <path d="M6 0L7.34708 4.1459H11.7063L8.17963 6.7082L9.52671 10.8541L6 8.2918L2.47329 10.8541L3.82037 6.7082L0.293661 4.1459H4.65292L6 0Z" fill="#FD6431"></path>
                            </svg>
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="11" viewBox="0 0 12 11" fill="none">
                                <path d="M6 0L7.34708 4.1459H11.7063L8.17963 6.7082L9.52671 10.8541L6 8.2918L2.47329 10.8541L3.82037 6.7082L0.293661 4.1459H4.65292L6 0Z" fill="#FD6431"></path>
                            </svg>
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="11" viewBox="0 0 12 11" fill="none">
                                <path d="M6 0L7.34708 4.1459H11.7063L8.17963 6.7082L9.52671 10.8541L6 8.2918L2.47329 10.8541L3.82037 6.7082L0.293661 4.1459H4.65292L6 0Z" fill="#FD6431"></path>
                            </svg>
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="11" viewBox="0 0 12 11" fill="none">
                                <path d="M6 0L7.34708 4.1459H11.7063L8.17963 6.7082L9.52671 10.8541L6 8.2918L2.47329 10.8541L3.82037 6.7082L0.293661 4.1459H4.65292L6 0Z" fill="#FD6431"></path>
                            </svg>
                        </p>
                    </div>
                    <p class="blueDark45 text12 flexGroup mt5"><svg class="mr10" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                            <g clip-path="url(#clip0_2758_26057)">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M2 5.6C2 2.504 4.504 0 7.6 0C10.696 0 13.2 2.504 13.2 5.6C13.2 9.8 7.6 16 7.6 16C7.6 16 2 9.8 2 5.6ZM7.6002 9.59999C9.80933 9.59999 11.6002 7.80913 11.6002 5.59999C11.6002 3.39085 9.80933 1.59999 7.6002 1.59999C5.39106 1.59999 3.6002 3.39085 3.6002 5.59999C3.6002 7.80913 5.39106 9.59999 7.6002 9.59999Z" fill="#5C6AA1"/>
                                <path d="M10.5496 6.25926L10.2796 7.96295L9.73206 7.47078C9.35245 7.75996 9.01181 8.49668 7.5335 8.5312C6.35769 8.5312 5.86764 7.86223 5.43532 7.5388L4.93516 7.98737L4.65088 6.29928L6.52955 6.55549L6.01171 7.0204C6.01171 7.0204 6.4558 7.70441 7.22285 7.75218L7.21978 4.972C6.80542 4.83857 6.50682 4.48527 6.50682 4.06707C6.50682 3.53387 6.98735 3.10193 7.58088 3.10193C8.17383 3.10193 8.65519 3.5339 8.65519 4.06707C8.65519 4.49175 8.3468 4.84895 7.92347 4.97691C7.9257 5.51997 7.93552 7.76257 7.92235 7.76257C8.55734 7.7462 9.15199 6.95031 9.15199 6.95031L8.66724 6.51497L10.5496 6.25926ZM8.13544 4.05197C8.13544 3.77759 7.88677 3.55486 7.5809 3.55486C7.27559 3.55486 7.02775 3.77759 7.02775 4.05197C7.02775 4.32689 7.27559 4.55013 7.5809 4.55013C7.88705 4.54986 8.13544 4.32686 8.13544 4.05197Z" fill="#5C6AA1"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_2758_26057">
                                    <rect width="16" height="16" fill="white"/>
                                </clipPath>
                            </defs>
                        </svg>Halong Bay, Ti Top Island, Surprise Cave</p>
                    <div class="formBox__type">
                        <ul>
                            <li class="flexGroup1 mb5">
                                <p class="blueDark45">Type of room:</p>
                                <p class="blueDark">1x Deluxe Balcony Cabin</p>
                            </li>
                            <li class="flexGroup1 mb5">
                                <p class="blueDark45">Duration:</p>
                                <p class="blueDark">2 Days/1 Night</p>
                            </li>
                            <li class="flexGroup1 mb5">
                                <p class="blueDark45">Passengers:</p>
                                <p class="blueDark">2 Adults</p>
                            </li>
                            <li class="flexGroup1 mb5">
                                <p class="blueDark45">Check-in:</p>
                                <p class="blueDark">Fri, Jan 28, 2022</p>
                            </li>
                            <li class="flexGroup1 mb5">
                                <p class="blueDark45">Check-out:</p>
                                <p class="blueDark">Mon, Jan 31, 2022</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="formBox">
        <div class="formBox__body">
            <div class="formBox__price">
                <div class="review__title ml10"><p class="text16 medium blueDark">Price</p></div>
                <div class="formBox__flex">
                    <div class="formBox__right">
                        <ul>
                            <li class="flexGroup1 blueDark">
                                <p style="display: grid">
                                    <span>Price per night</span>
                                    <span class="text12 medium">1 rooms</span>
                                </p>
                                <p>USD 40</p>
                            </li>
                            <li class="flexGroup1 blueDark">
                                <p>Number of nights</p>
                                <p>x2</p>
                            </li>
                            <li class="flexGroup1 blueDark">
                                <p>Shutter bus fee</p>
                                <p>USD 5</p>
                            </li>
                            <li class="flexGroup1 blueDark">
                                <p>Taxes and fees</p>
                                <p>USD 10</p>
                            </li>
                            <li class="flexGroup1 mt10 total__charges">
                                <p class="medium text16 blueDark mt5">Total charges</p>
                                <p class="medium green400 text16 text-right ml10 mt5 flex1">USD 66.88<span class="d-block blueDark45 text12 regular">Includes taxes & fees</span></p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="formBox">
        <div class="formBox__body">
            <div class="review__title ml10"><p class="text16 medium blueDark">Passenger details</p></div>
            <div class="formBox__contact ml10">
                <div class="travelerTable__header">
                    <div class="travelerTable__cell">
                        <p class="blueDark medium">Full Name</p>
                    </div>
                    <div class="travelerTable__cell">
                        <p class="blueDark medium">Date of Birth</p>
                    </div>
                    <div class="travelerTable__cell">
                        <p class="blueDark medium">Passport</p>
                    </div>
                    <div class="travelerTable__cell">
                        <p class="blueDark medium">Nationality</p>
                    </div>
                    <div class="travelerTable__cell">
                        <p class="blueDark medium">Date of Issued</p>
                    </div>
                    <div class="travelerTable__cell">
                        <p class="blueDark medium">Date of Expired</p>
                    </div>
                    <div class="travelerTable__cell">
                        <p class="blueDark medium">Frequent Flyer number</p>
                    </div>
                </div>
                <div class="travelerTable__body">
                    <div class="travelerTable__row">
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">Mrs. Polidura Mora/Andrea </p>
                        </div>
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">7/7/1995</p>
                        </div>
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">PAK485069</p>
                        </div>
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">Spaniard</p>
                        </div>
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">2019-12-10</p>
                        </div>
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">2024-12-10</p>
                        </div>
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">&nbsp;-</p>
                        </div>
                    </div>
                    <div class="travelerTable__row">
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">Mrs. Graneras Galiano/Lucia</p>
                        </div>
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">5/7/1995</p>
                        </div>
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">PAE887770</p>
                        </div>
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">Spaniard</p>
                        </div>
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">2017-06-08</p>
                        </div>
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">2022-06-08</p>
                        </div>
                        <div class="travelerTable__cell">
                            <p class="tex14 blueDark">&nbsp;-</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="formBox">
        <div class="formBox__body">
            <div class="review__title ml10"><p class="text16 medium blueDark">Contact email</p></div>
            <div class="formBox__contact ml10">
                <div class="formBox__flex">
                    <div class="formBox__contact__line">
                        <div class="d-block">
                            <div class="flexGroup2">
                                <p class="blueDark medium">Phone</p>
                            </div>
                        </div>
                        <div class="d-block">
                            <p class="blueDark medium">Email</p>
                        </div>
                    </div>
                </div>
                <div class="formBox__flex">
                    <div class="formBox__contact__line">
                        <div class="d-block">
                            <div class="flexGroup2">
                                <p class="blueDark">(+84) 091 888 8888</p>
                            </div>
                        </div>
                        <div class="d-block">
                            <p class="blueDark">phamducquang@gmail.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="formBox">
        <div class="formBox__body">
            <div class="review__title ml10"><p class="text16 medium blueDark">Payment option</p></div>
            <div class="formBox__payment ml10">
                <div class="formBox__payment__item">
                    <div class="radio">
                        <input id="fl11" type="radio" name="fl" checked="">
                        <label for="fl11">Pay by Credit/Debit Cards</label>
                    </div>
                    <ul class="formBox__payment__card">
                        <li><img src="images/jcb.png"></li>
                        <li><img src="images/visa.png"></li>
                        <li><img src="images/mastercard.png"></li>
                        <li><img src="images/card-dinner.png"></li>
                    </ul>
                </div>
                <div class="formBox__payment__item">
                    <div class="radio">
                        <input id="fl22" type="radio" name="fl">
                        <label for="fl22">Pay by QR Code</label>
                    </div>
                </div>
                <div class="button_qrcode"><button type="button"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="18" viewBox="0 0 24 18" fill="none">
                            <path d="M4.5 6.75C4.69891 6.75 4.88968 6.67098 5.03033 6.53033C5.17098 6.38968 5.25 6.19891 5.25 6V2.25H9C9.19891 2.25 9.38968 2.17098 9.53033 2.03033C9.67098 1.88968 9.75 1.69891 9.75 1.5C9.75 1.30109 9.67098 1.11032 9.53033 0.96967C9.38968 0.829018 9.19891 0.75 9 0.75H4.5C4.30109 0.75 4.11032 0.829018 3.96967 0.96967C3.82902 1.11032 3.75 1.30109 3.75 1.5V6C3.75 6.19891 3.82902 6.38968 3.96967 6.53033C4.11032 6.67098 4.30109 6.75 4.5 6.75Z" fill="#FFFDFD"/>
                            <path d="M15 2.25H18.75V6C18.75 6.19891 18.829 6.38968 18.9697 6.53033C19.1103 6.67098 19.3011 6.75 19.5 6.75C19.6989 6.75 19.8897 6.67098 20.0303 6.53033C20.171 6.38968 20.25 6.19891 20.25 6V1.5C20.25 1.30109 20.171 1.11032 20.0303 0.96967C19.8897 0.829018 19.6989 0.75 19.5 0.75H15C14.8011 0.75 14.6103 0.829018 14.4697 0.96967C14.329 1.11032 14.25 1.30109 14.25 1.5C14.25 1.69891 14.329 1.88968 14.4697 2.03033C14.6103 2.17098 14.8011 2.25 15 2.25Z" fill="#FFFDFD"/>
                            <path d="M9 15.75H5.25V12C5.25 11.8011 5.17098 11.6103 5.03033 11.4697C4.88968 11.329 4.69891 11.25 4.5 11.25C4.30109 11.25 4.11032 11.329 3.96967 11.4697C3.82902 11.6103 3.75 11.8011 3.75 12V16.5C3.75 16.6989 3.82902 16.8897 3.96967 17.0303C4.11032 17.171 4.30109 17.25 4.5 17.25H9C9.19891 17.25 9.38968 17.171 9.53033 17.0303C9.67098 16.8897 9.75 16.6989 9.75 16.5C9.75 16.3011 9.67098 16.1103 9.53033 15.9697C9.38968 15.829 9.19891 15.75 9 15.75Z" fill="#FFFDFD"/>
                            <path d="M19.5 11.25C19.3011 11.25 19.1103 11.329 18.9697 11.4697C18.829 11.6103 18.75 11.8011 18.75 12V15.75H15C14.8011 15.75 14.6103 15.829 14.4697 15.9697C14.329 16.1103 14.25 16.3011 14.25 16.5C14.25 16.6989 14.329 16.8897 14.4697 17.0303C14.6103 17.171 14.8011 17.25 15 17.25H19.5C19.6989 17.25 19.8897 17.171 20.0303 17.0303C20.171 16.8897 20.25 16.6989 20.25 16.5V12C20.25 11.8011 20.171 11.6103 20.0303 11.4697C19.8897 11.329 19.6989 11.25 19.5 11.25Z" fill="#FFFDFD"/>
                            <path d="M22.5 8.25H1.5C1.30109 8.25 1.11032 8.32902 0.96967 8.46967C0.829018 8.61032 0.75 8.80109 0.75 9C0.75 9.19891 0.829018 9.38968 0.96967 9.53033C1.11032 9.67098 1.30109 9.75 1.5 9.75H22.5C22.6989 9.75 22.8897 9.67098 23.0303 9.53033C23.171 9.38968 23.25 9.19891 23.25 9C23.25 8.80109 23.171 8.61032 23.0303 8.46967C22.8897 8.32902 22.6989 8.25 22.5 8.25Z" fill="#FFFDFD"/>
                        </svg>QR Code</button></div>
            </div>
        </div>
    </div>
    <div class="formBox">
        <div class="formBox__body">
            <div class="review__title ml10"><p class="text16 medium blueDark">Term of use</p></div>
            <div class="formBox__term ml10">
                <p>Conditions of website use</p>
                <p>By accessing and using our website for any purpose of searching, referencing or booking, you acknowledge that you’re fully understanding and accepting, as well as agreeing not to violate our Terms and Conditions.</p>
                <p>We recommend you to read the following terms and conditions carefully before purchasing our products. If you object to any of it please leave this website immediately.</p>
                <p>Please also be noted that Cambodia reserves the rights to cancel or terminate any booking if it’s in such case:</p>
                <ul>
                    <li>(i) required by law.</li>
                    <li>(ii) payment is not made in time.</li>
                    <li>(iii) ticket availability issues.</li>
                    <li>(iv) system errors or any technical problems that may cause us in processing customer’s request.</li>
                </ul>
                <p>Conditions of website use</p>
                <p>By accessing and using our website for any purpose of searching, referencing or booking, you acknowledge that you’re fully understanding and accepting, as well as agreeing not to violate our Terms and Conditions.</p>
                <p>We recommend you to read the following terms and conditions carefully before purchasing our products. If you object to any of it please leave this website immediately.</p>
                <p>Please also be noted that Cambodia reserves the rights to cancel or terminate any booking if it’s in such case:</p>
                <ul>
                    <li>(i) required by law.</li>
                    <li>(ii) payment is not made in time.</li>
                    <li>(iii) ticket availability issues.</li>
                    <li>(iv) system errors or any technical problems that may cause us in processing customer’s request.</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="flightReview__checkbox">
        <div class="checkbox">
            <input id="pp13" type="checkbox">
            <label class="blueDark" for="pp13">I have read and agree to all the&nbsp;<a href="termsOfUse.html" class="aLink">Term of Use</a>&nbsp;specified.</label>
        </div>
    </div>
    <div class="flightReview__btn"><a href="payment.html" class="btn btn-orange btn-lg">Continue</a></div>
</div>