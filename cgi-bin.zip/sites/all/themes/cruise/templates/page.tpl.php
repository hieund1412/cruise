<?php
$theme = '/sites/all/themes/newtheme/';

?>
<main class="wrapper">
    <section class="flightPassenger">
        <div class="passenger__header">
            <div class="container">
                <div class="header__body">
                    <?php echo blk_header();?>
                </div>
                <div class="passenger__step">
                    <ul class="progressbar">
                        <li class="complete">Choose Room</li>
                        <li class="active">Guest Info</li>
                        <li>Review</li>
                        <li>Payment</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="passenger__body">
            <div class="container">
                <?php print render($page['content']); ?>

            </div>
        </div>
    </section>

</main>
<?php echo blk_footer();?>

